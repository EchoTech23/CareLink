module.exports = {
  content: [
    "./app/**/*.{html,js,jsx, tsx}", // Adjust this based on your project structure
  ],
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
};
